package Vetores;

import java.util.Scanner;

public class ex_m1 {

    public static void main(String[] Args) {
        Scanner entrada = new Scanner(System.in);
        int num, par=0, impar=0;
        double soma=0, media, maior=0, menor=0, diag_principal=0, diag_secundaria=0;

        System.out.print("Digite o tamanho da matriz quadrada(um número de 3 a 11): ");
        num = entrada.nextInt();

        while ((num < 3 || num > 11) || (num % 2 == 0)) {
            System.out.print("número invalido, digite novamente:");
            num=entrada.nextInt();
        }
        
        media=num*num;
        final int LIN = num;
        final int COL = num;
        int[][] matriz = new int[LIN][COL];

        for (int lin = 0; lin < LIN; lin++) {
            for (int col = 0; col < COL; col++) {
                System.out.print("[" + lin + "," + col + "]:");
                matriz[lin][col] = entrada.nextInt();
                soma += matriz[lin][col];
                if ((lin==0) && (col==0)){
                    maior=matriz[lin][col];
                    menor=matriz[lin][col];
                }else{
                    if (matriz[lin][col]>maior)
                        maior=matriz[lin][col];
                    if (matriz[lin][col]<menor)
                        menor=matriz[lin][col];                                  
                }
                if (matriz[lin][col] % 2==0){
                    par = par + 1;
                }else{
                    impar = impar + 1;
                }
                if (lin==col){
                    diag_principal+= matriz[lin][col]; 
                }
                
                    
                
            }
        }
        
        for(int lin = LIN - 1; lin >= 0; lin--) {
			for(int col = COL - 1; col >= 0; col--) {
				if(lin + col == matriz.length - 1) {
					diag_secundaria += matriz[lin][col];
				}
			}
		}
        
        
        for (int lin = 0; lin < LIN; lin++) {
            System.out.println();
            for (int col = 0; col < COL; col++) {
                System.out.print(matriz[lin][col] + " ");
            }
        }
        System.out.println();
        System.out.println("soma de todos os elementos: " + soma);
        System.out.println("media dos elementos digitados: " + soma/media);
        System.out.println("Maior elemento digitado: " + maior);
        System.out.println("Menor elemento digitado: " + menor);
        System.out.println("Quantidade de números pares: " + par);
        System.out.println("Quantidade de números ímpares: " + impar);
        System.out.println("Soma dos números da diagonal principal: " + diag_principal);
        System.out.println("Soma dos números da diagonal secundária: " + diag_secundaria);
        
        
    }
}