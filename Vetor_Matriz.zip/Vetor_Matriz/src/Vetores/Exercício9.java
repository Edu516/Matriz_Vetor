
package Vetores;

import java.util.Scanner;


public class Exercício9 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		char[] letra = new char[10];
		String text;

		System.out.print("Digite um texto(contendo até 10 caracteres): ");

		text = entrada.nextLine();

		for (int x = 0; x < 10; x++) {

			letra[x] = text.charAt(x);

		}

		System.out.println("Texto: ");
		for (int x = 0; x < 10; x++) {
			System.out.println(letra[x] + " ");
		}

	}
}
