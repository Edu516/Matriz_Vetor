package Vetores;

import java.util.Scanner;

public class ex_m5 {
    public static void main(String[]Args){
        Scanner entrada = new Scanner(System.in);
        int vetor [] = new int[20];
    int vpar [] = new int[20];
    int vimpar [] = new int [20];
    
    
    for (int x = 0 ; x < 20; x++){
        System.out.print("Digite o número "+(x+1)+": ");
        vetor[x] = entrada.nextInt();
        
        if(vetor[x] % 3 == 0){
            vimpar[x] =  vetor[x];
        }else{
            vpar[x] = vetor[x];
        }
        
    }
        System.out.println("Vetor: ");
for (int x = 0; x < 20; x++){
    System.out.print(" "+vetor[x]+" ");
}
        System.out.println("");

        System.out.println("Vetorpar: ");
for (int x = 0; x < 20; x++){
    System.out.print(" "+vpar[x]+" ");
}
        System.out.println("");
        System.out.println("Vetor impar: ");
for (int x = 0; x < 20; x++){
    System.out.print(" "+vimpar[x]+" ");
}


    }
}  
