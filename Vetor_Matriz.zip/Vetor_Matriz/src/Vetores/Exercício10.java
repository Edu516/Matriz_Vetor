
package Vetores;

import java.util.Scanner;

public class Exercício10 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		int d = 0, m = 0, a = 0;
		int[] data = new int[3];

		do {
			System.out.print("Digite o ano: ");
			a = entrada.nextInt();

			System.out.print("Digite o mes: ");
			m = entrada.nextInt();

			System.out.print("Digite o dia: ");
			d = entrada.nextInt();

		} while (((d < 0) || (d > 31)) || ((m < 0) || (m > 12)) || (a < 0) || (a > 9999));

		data[0] = d;
		data[1] = m;
		data[2] = a;

	}
}
