
package Vetores;

import java.util.Scanner;

public class Exercício3 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		float soma = 0;
		final int TAM = 4;
		float[] vetor = new float[TAM];
		for (int x = 0; x < TAM; x++) {
			System.out.print("Informe um número:");
			vetor[x] = entrada.nextFloat();
		}
		for (int x = 0; x < TAM; x++) {
			soma = vetor[x] + soma;
		}
		System.out.print("Sua media é: " + soma / TAM);
	}
}
