
package Vetores;

import java.util.Scanner;
public class Exercício14 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		int[] id = new int[30];
		float[] alt;
		alt = new float[30];
		float media = 0;
		int cont = 0;

		System.out.println("Digite as idades: ");
		for (int x = 0; x < 30; x++) {
			System.out.print("Digite a idade " + (x + 1) + ": ");
			id[x] = entrada.nextInt();
		}

		System.out.println("Digite as alturas: ");
		for (int x = 0; x < 30; x++) {
			System.out.print("Digite a altura " + (x + 1) + ": ");
			alt[x] = entrada.nextInt();
			media = media + alt[x];
		}

		for (int x = 0; x < 30; x++) {

			if ((id[x] > 13) && (alt[x] < media)) {
				cont = cont + 1;
			}
		}
		System.out.println("Número de alunos abaixo da altura: " + cont);

	}
}
