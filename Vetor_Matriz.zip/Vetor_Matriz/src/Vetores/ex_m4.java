package Vetores;

import java.util.Scanner;

public class ex_m4 {

    public static void main(String[] Args) {
        Scanner entrada = new Scanner(System.in);
        int n;
        double soma_saltos = 0, campeao = 0, perdedor = 0;

        System.out.print("Quantos atletas irão saltar?");
        n = entrada.nextInt();

        double[][] matriz = new double[n][6];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 6; j++) {
                if (j != 5) {
                    System.out.print("Digite o " + j + "º salto do " + i + "º aluno:");
                    matriz[i][j] = entrada.nextDouble();
                    soma_saltos += matriz[i][j];
                    matriz[i][5] = soma_saltos / 5;
                } else {
                    System.out.println("A média de saltos do " + i + "º atleta é:" + matriz[i][5]);
                    soma_saltos = 0;
                }
            }
            if (i == 1) {
                campeao = matriz[i][5];
                perdedor = matriz[i][5];
            } else {
                if (matriz[i][5] > campeao) {
                    campeao = matriz[i][5];
                }
                if (matriz[i][5] < perdedor) {
                    perdedor = matriz[i][5];
                }
            }

        }

        System.out.println();

        for (int i = 0; i < n; i++) {
            System.out.println();
            System.out.println(i + "º atleta:");
            for (int j = 0; j < 6; j++) {
                if (j != 5) {
                    System.out.println(j + "º salto:" + matriz[i][j]);
                } else {
                    System.out.println("Média de saltos: " + matriz[i][j]);
                }

            }

        }
        System.out.println();
        System.out.println("Média de saltos do campeão: " + campeao);
        System.out.println("Média de saltos do últimos colocado: " + perdedor);
    }
}
