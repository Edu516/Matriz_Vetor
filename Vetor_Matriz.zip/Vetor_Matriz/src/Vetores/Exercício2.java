
package Vetores;

import java.util.Scanner;

public class Exercício2 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		final int TAM = 10;
		float[] vetor = new float[TAM];
		for (int x = 0; x < TAM; x++) {
			System.out.print("Informe um número:");
			vetor[x] = entrada.nextFloat();
		}
		for (int x = TAM; x > 0; x--) {
			System.out.print(vetor[x]);
		}
	}
}
