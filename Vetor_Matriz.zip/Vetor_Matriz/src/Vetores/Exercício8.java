
package Vetores;

import java.util.ArrayList;
import java.util.Scanner;

public class Exercício8 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		char[] alfabeto = new char[26];
		int numsenha = 0;

		do {
			System.out.print("Quantos caracteres terá sua senha: ");
			numsenha = entrada.nextInt();
		} while ((numsenha < 0) || (numsenha > 26));

		ArrayList<String> lista = new ArrayList<>();

		for (int i = 97; i < 97 + numsenha; i++) {
			char a = (char) i;
			lista.add(String.valueOf(a));
			System.out.print(a + " ");

		}
	}
}
