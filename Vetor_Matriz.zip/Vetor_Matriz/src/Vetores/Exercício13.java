
package Vetores;

import java.util.Scanner;


public class Exercício13 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		int[] v1 = new int[10];
		int[] v2 = new int[10];

		System.out.println("Preencha o vetor 1: ");
		for (int s = 0; s < 10; s++) {

			System.out.print("Digte o número " + (s + 1) + ": ");
			v1[s] = entrada.nextInt();
		}

		System.out.println("Preencha o vetor 2: ");
		for (int s = 0; s < 10; s++) {

			System.out.print("Digte o número " + (s + 1) + ": ");
			v2[s] = entrada.nextInt();
		}

		for (int s = 0; s < 10; s++) {
			System.out.print(" " + v1[s] + " ");
			System.out.print(" " + v2[s] + " ");
		}

	}
}
