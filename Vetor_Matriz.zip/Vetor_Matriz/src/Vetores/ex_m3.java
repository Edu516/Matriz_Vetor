package Vetores;

import java.util.Scanner;

public class ex_m3 {

    public static void main(String[] Args) {
        Scanner entrada = new Scanner(System.in);
        int n;
        double media_geral = 0;
        int maior_nota = 0, menor_nota = 0, maior_media = 0, menor_media = 0;
        int aluno_maior_nota = 0, aluno_menor_nota = 0, aluno_maior_media = 0, aluno_menor_media = 0;

        System.out.print("Quantos alunos tem? ");
        n = entrada.nextInt();
        
        
        String[] nome = new String[n];

        double[][] notas = new double[n][3];
        for (int i = 0; i < n; i++) {
            entrada.nextLine();
            System.out.print("Informe o nome do " + i + "º aluno:");
            nome[i] = entrada.nextLine();
            System.out.print("Informe a primeira nota: ");
            notas[i][0] = entrada.nextDouble();
            System.out.print("Informe a segunda nota: ");
            notas[i][1] = entrada.nextDouble();
            notas[i][2] = (notas[i][0] + notas[i][1]) / 2;
            media_geral += notas[i][2];
            if (i == 0) {
                if (notas[i][0] > notas[i][1]) {
                    aluno_maior_nota = i;
                    maior_nota = 0;
                    aluno_menor_media = i;
                    menor_nota = 1;
                } else {
                    aluno_maior_nota = i;
                    maior_nota = 1;
                    aluno_menor_nota = i;
                    menor_nota = 0;
                }
                aluno_maior_media = i;
                maior_media = 2;
                aluno_menor_media = i;
                menor_media = 2;
            } else {
                if (notas[i][0] > notas[aluno_maior_nota][maior_nota]) {
                    aluno_maior_nota = i;
                    maior_nota = 0;
                }
                if (notas[i][1] > notas[aluno_maior_nota][maior_nota]) {
                    aluno_maior_nota = i;
                    maior_nota = 1;
                }
                if (notas[i][0] < notas[aluno_menor_nota][menor_nota]) {
                    aluno_menor_nota = i;
                    menor_nota = 0;
                }
                if (notas[i][1] < notas[aluno_menor_nota][menor_nota]) {
                    aluno_menor_nota = i;
                    menor_nota = 1;
                }
                if (notas[i][2] > notas[aluno_maior_media][maior_media]) {
                    aluno_maior_media = i;
                    maior_media = 2;
                }
                if (notas[i][2] < notas[aluno_menor_media][menor_media]) {
                    aluno_menor_media = i;
                    menor_media = 2;
                }
            }

        }
        media_geral = media_geral / n;

        for (int i = 0; i < n; i++) {
            System.out.println("");
            System.out.print("Aluno: " + nome[i] + " ");
            for (int j = 0; j < 3; j++) {                
                if (j == 2) {
                    System.out.print("Media do aluno: " + notas[i][j] + " ");
                }else{
                    System.out.print("Nota " + j + ": " + notas[i][j]+ " ");
                }
            }
            
        }
        System.out.println();
        System.out.println("Alunos acima da media geral da turma:");
        for (int i = 0; i <n; i++) {
            if (notas[i][2] > media_geral)
                System.out.println(nome[i]);            
        }
        System.out.println("Alunos abaixo da media geral da turma: ");
        for (int i = 0; i < n; i++) {
            if ( notas[i][2] < media_geral)
                System.out.println(nome[i]);
            
        }
 

        
        System.out.println("O aluno com nome " + nome[aluno_maior_nota] + " com maior nota foi: " + notas[aluno_maior_nota][maior_nota]);
        System.out.println("O aluno com nome " + nome[aluno_menor_nota] + " com menor nota foi: " + notas[aluno_menor_nota][menor_nota]);
        System.out.println("O aluno com nome " + nome[aluno_maior_media] + " com maior media foi: " + notas[aluno_maior_media][maior_media]);
        System.out.println("O aluno com nome " + nome[aluno_menor_media] + " com menor media foi: " + notas[aluno_menor_media][menor_media]);
        System.out.println("A média geral da turma é: " + media_geral);

    }
}
