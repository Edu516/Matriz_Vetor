
package Vetores;

import java.util.Scanner;


public class Exercício5 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		final int TAM = 5;
		final int DIV = 2;
		int impar1 = 0;
		int par1 = 0;
		float[] vetor = new float[TAM];
		float[] par = new float[TAM];
		float[] impar = new float[TAM];
		for (int x = 0; x < TAM; x++) {
			System.out.print("Informe uma letra:");
			vetor[x] = entrada.nextInt();
		}
		for (int x = 0; x < TAM; x++) {
			if (vetor[x] % DIV == 0) {
				par1++;
				par[x] = vetor[x];
			} else {
				impar1++;
				impar[x] = vetor[x];
			}
		}
		System.out.print("O vetor é: ");
		for (int x = 0; x < TAM; x++) {
			System.out.println(vetor[x]);

		}
		System.out.print("O par é: ");
		for (int x = 0; x < par1; x++) {
			System.out.println(par[x]);
		}
		System.out.print("O impar é: ");
		for (int x = 0; x < impar1; x++) {
			System.out.println(+impar[x]);
		}
	}
}
