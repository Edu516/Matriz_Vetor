
package Vetores;

import java.util.Scanner;

public class Exercício6 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		final int ALUN = 10;
		final int medi = 4;
		int cont = 0;
		float[] vetor = new float[ALUN];
		for (int x = 0; x < ALUN; x++) {
			int media = 0;
			System.out.println("Digite suas 4 notas");
			int n1 = entrada.nextInt();
			int n2 = entrada.nextInt();
			int n3 = entrada.nextInt();
			int n4 = entrada.nextInt();
			media = n1 + n2 + n3 + n4 / medi;
			vetor[x] = media;
		}
		for (int x = 0; x < ALUN; x++) {
			if (vetor[x] >= 7) {
				cont++;
			}
		}
		System.out.println("O numero de alunos acima da média é:" + cont);
	}
}
