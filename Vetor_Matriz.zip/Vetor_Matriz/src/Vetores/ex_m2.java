package Vetores;

import java.util.Scanner;

public class ex_m2 {

    public static void main(String[] Args) {
        Scanner entrada = new Scanner(System.in);
        double produto1 = 0, produto2 = 0, produto3 = 0, produto4 = 0, produto5 = 0, soma = 0;
        double mercado1 = 0, mercado2 = 0, mercado3 = 0, mercado4 = 0, mercado5 = 0, mais_barato = 0, mais_caro = 0;

        final int LIN = 5;
        final int COL = 5;
        double[][] matriz = new double[LIN][COL];

        for (int lin = 0; lin < LIN; lin++) {
            for (int col = 0; col < COL; col++) {
                System.out.print("supermercado " + lin + ", produto " + col + ":");
                matriz[lin][col] = entrada.nextDouble();
                soma += matriz[lin][col];
                if (col == 0) {
                    produto1 += matriz[lin][col];
                } else if (col == 1) {
                    produto2 += matriz[lin][col];
                } else if (col == 2) {
                    produto3 += matriz[lin][col];
                } else if (col == 3) {
                    produto4 += matriz[lin][col];
                } else if (col == 4) {
                    produto5 += matriz[lin][col];
                }
                if (lin == 0) {
                    mercado1 += matriz[lin][col];
                } else if (lin == 1) {
                    mercado2 += matriz[lin][col];
                } else if (lin == 2) {
                    mercado3 += matriz[lin][col];
                } else if (lin == 3) {
                    mercado4 += matriz[lin][col];
                } else if (lin == 4) {
                    mercado5 += matriz[lin][col];
                }
            }
            if (lin==1){
                mais_barato=soma;
                mais_caro=soma;
            }else{
                if (soma < mais_barato)
                mais_barato = soma;
                if (soma > mais_caro) 
                mais_caro = soma;
            }
            soma = 0;
        }
        for (int lin = 0; lin < LIN; lin++) {
            System.out.println();
            System.out.println("supermercado: " + lin);
            for (int col = 0; col < COL; col++) {
                System.out.print(matriz[lin][col] + " ");

            }
        }
        System.out.println();
        System.out.println("Média de preço do 1º produto: R$ " + produto1 / 5);
        System.out.println("Média de preço do 2º produto: R$ " + produto2 / 5);
        System.out.println("Média de preço do 3º produto: R$ " + produto3 / 5);
        System.out.println("Média de preço do 4º produto: R$ " + produto4 / 5);
        System.out.println("Média de preço do 5º produto: R$ " + produto5 / 5);
        System.out.println("O preço total do 1º supermercado: R$ " + mercado1);
        System.out.println("O preço total do 2º supermercado: R$ " + mercado2);
        System.out.println("O preço total do 3º supermercado: R$ " + mercado3);
        System.out.println("O preço total do 4º supermercado: R$ " + mercado4);
        System.out.println("O preço total do 5º supermercado: R$ " + mercado5);
        System.out.println("Preço total no supermercado mais barato: R$ " + mais_barato);
        System.out.println("Preço total no supermercado mais caro: R$ " + mais_caro);

    }
}
