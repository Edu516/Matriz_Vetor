
package Vetores;

import java.util.Scanner;


public class Exercício15 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		final int PAM = 3;
		int[] vetor = new int[PAM];
		int cont = 1;
		int x = 0;
		do {

			System.out.println("Informe um numero");
			int num = entrada.nextInt();
			if (num <= 20 && num >= 0) {
				vetor[x] = num;
				cont++;
				x++;
			} else {
				System.out.println("Digitou fora do intervalo");
			}
		} while (cont <= 3);
		for (x = 0; x < PAM; x++) {
			for (int y = vetor[x]; y > 0; y--) {
				System.out.print("#");
			}
			System.out.println("");
		}
	}
}
