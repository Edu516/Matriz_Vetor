
package Vetores;

import java.util.Scanner;


public class Exercício7 {

	public static void main(String[] arg) {
		Scanner entrada = new Scanner(System.in);
		int soma = 0;
		final int TAM = 5;
		int mult = 1;

		int[] vetor = new int[TAM];
		for (int x = 0; x < TAM; x++) {
			System.out.print("Informe um número:");
			vetor[x] = entrada.nextInt();

		}

		for (int x = 0; x < TAM; x++) {
			soma = vetor[x] + soma;
			mult = vetor[x] * mult;
			System.out.println(vetor[x]);

		}
		System.out.println("Soma é " + soma);
		System.out.println("  Multiplicação:" + mult);

	}
}
