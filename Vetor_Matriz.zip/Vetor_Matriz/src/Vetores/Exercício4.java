
package Vetores;

import java.util.Scanner;

public class Exercício4 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		int contador = 0;
		char[] consoante = new char[10];
		char[] letras = new char[10];
		String letra;

		for (int x = 0; x < 10; x++) {
			System.out.print("Digite a letra " + (x + 1) + ": ");
			letra = entrada.next();
			letras[x] = letra.charAt(0);
			if ((!"a".equals(letra)) && (!"e".equals(letra)) && (!"i".equals(letra)) && (!"o".equals(letra))
					&& (!"u".equals(letra))) {
				consoante[contador] = letra.charAt(0);
				contador = contador + 1;
			}
		}

		System.out.println("");
		System.out.println("Consoantes digitadas: " + contador);
		for (int x = 0; x < 10; x++) {

			System.out.print(" " + consoante[x] + " ");
		}
	}
}
