
package Vetores;

import java.util.Scanner;

public class Exercício12 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		int[] id = new int[5];
		float[] alt;
		int menor = 0, maior = 0;
		float baixo = 0, alto = 0, mediaalt = 0, mediaida = 0;

		alt = new float[5];

		for (int x = 0; x < 5; x++) {
			System.out.print("Digite a idade do " + (x + 1) + "°: ");
			id[x] = entrada.nextInt();

			System.out.print("Digite a altura do " + (x + 1) + "°: ");
			alt[x] = entrada.nextFloat();

			if (x == 0) {
				menor = id[x];
				maior = id[x];
				baixo = alt[x];
				alto = alt[x];
			} else {
				if (id[x] < menor) {
					menor = id[x];
				}
				if (id[x] > maior) {
					maior = id[x];
				}
				if (alt[x] < baixo) {
					baixo = alt[x];
				}

				if (alt[x] > alto) {
					alto = alt[x];
				}
				mediaalt = mediaalt + alt[x];
				mediaida = mediaida + id[x];
			}

		}

		mediaalt = mediaalt / 5;
		mediaida = mediaida / 5;
		for (int x = 4; x >= 0; x--) {
			System.out.print("idade do " + (x + 1) + "°: " + id[x] + "  ");

		}

		System.out.println("");
		System.out.println("Mais novo: " + menor + " mais velho: " + maior);
		System.out.println("Mais baixo: " + baixo + " mais alto: " + alto);

		for (int x = 0; x < 5; x++) {
			if (id[x] < mediaida) {
				System.out.println("A Pessoa " + (x + 1) + " abaixo da média de idade: " + id[x]);
			} else {
				System.out.println("A Pessoa " + (x + 1) + " acima da média de idade: " + id[x]);
			}

			if (alt[x] < mediaida) {
				System.out.println("A Pessoa " + (x + 1) + " abaixo da média de altura: " + alt[x]);
			} else {
				System.out.println("A Pessoa " + (x + 1) + " acima da média de altura: " + alt[x]);
			}
		}

	}
}
